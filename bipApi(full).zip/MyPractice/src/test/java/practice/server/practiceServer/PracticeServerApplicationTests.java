package practice.server.practiceServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
